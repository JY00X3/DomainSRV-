# NO RATE LIMIT

Created: June 19, 2025 5:09 PM

### **Description**:

A no rate limit vulnerability is a security flaw in a web application or API that fails to restrict the number of requests a user or client can make within a specific timeframe. This allows attackers to send excessive requests, potentially leading to abuse or exploitation.

GENRAL FORM :  

Steps to perform No Rate Limit Attacks:

- Capture the request in Burp
- Send the request to Intruder
- Choose the target position
- Choose the payload
- Enter the payloads
- Start the Attack

To check if the OTP is right or not always keep an eye on the following

- Grep Parameter
- Content Length
- Status

### **Attack Scenarios**:

### **1- ACCOUNT TAKEOVER VIA NO RATE LIMIT (BRUTE FORCE  OTP )**

**Description**: IN THIS SCENRIO WE HAVE  A MEDCAIL CARE WEBSITE 

ITS ALLOW US TO SIGN IN WITH THE PHONE NUMBER 

![image.png](image.png)

1-WE SIGN UP WITH  A NUMBER AND  WRITE WRONG OTP 

![image.png](image%201.png)

3-INTERCEP THE REQUEST AND   SEND IT TO INTRUDER 

4- MARK THE OTP PARAMETER  AND SET THE PAYLOAD TYPE   NUMBERS

5- IDENTEFY HOW MANY REQUESTS THE SERVER ACEPT BEFORE  BLOCKING U   BY TRY AND ERROR (SET  THE  PAYLOAD  5  NUMBERS FOR EX THE TRY 6  THEN 7 )

![image.png](image%202.png)

6- SET THE THROTTLE  TO MITIGATE BLOCKING BY THE SERVER  3000

7- FITCH FOR 200 OK  RESPONSE 

![image.png](image%203.png)

U CAN USE GRAP AND MATCH FOR  THE CASES THAT THE  RESPONE CODE DOESNOT CHANGE 

![image.png](image%204.png)

OBJECTIVE LEARN : 

1- INSTALL AND CONFIG THROTTLE    

[https://www.youtube.com/watch?v=gMELf8U8OkE&ab_channel=RyanArmstrong](https://www.youtube.com/watch?v=gMELf8U8OkE&ab_channel=RyanArmstrong)

### **2- No rate limit leads to SPAMMING post**

1- INTERCEPT  THE CREATING NEW POST  REQUEST

2- SEND TO INTRUDER  AND AIM TH CONTENT LENGTH FOR PAYLOAD

3- PUT THE PAYLOAD  TYPE  NUMBERS  FROM 0 TO 50  

![image.png](image%205.png)

THAT WILL FLOOD 50  POSTS IN THE PLATFORM 

REPORT :

[Reddit disclosed on HackerOne: No rate limit leads to spaming post](https://hackerone.com/reports/1206004)

### 3- NO RATE LIMIT FLOODING  MAILS

1- WRITE  UR MAIL IN THE FORGET THE PASSWORD FUNCTION

2- INTERCEPT THE  REQUEST 

3- AIM FOR Q IN THE ACCEPTING LANGUAGE  HEADER

> then add only 0.5 Accept-Language: en-US,en;q=$0.5$ like this
> 

![image.png](image%206.png)

4- PUT THE PAYLOAD NUMBERS  0 → 50

 REPORT:

[NO RATE LIMIT IN JUST 5 MIN](https://medium.com/@milanjain7906/no-rate-limit-in-just-5-min-222abde54004)

### 4- BAYPASSING IP BLOCKING VIA FAKEIP EXTENTION

### **IP Spoofing**

IP spoofing involves altering the source IP address of a request to make it appear as though it's coming from a different device. By rotating through different IP addresses an attacker can bypass the limit set on a specific IP.

```bash
Copyproxychains curl -X POST https://target.com/login -d "user=admin&pass=1234"
```

You can also use the Burp Suite *Fakip/Ip-rotator* extension to bypass rate limits by choosing preferred options:

![None](https://miro.medium.com/v2/resize:fit:700/1*iCpK1sBNvDNUl3ndIcDquA.png)

[**GitHub - AeolusTF/BurpFakeIP: 一个用于伪造ip地址进行爆破的Burp Suite插件一个用于伪造ip地址进行爆破的Burp Suite插件. Contribute to AeolusTF/BurpFakeIP development by creating an account on GitHub.**
github.com](https://github.com/AeolusTF/BurpFakeIP/tree/master)

[**GitHub - PortSwigger/ip-rotate: Extension for Burp Suite which uses AWS API Gateway to rotate your…Extension for Burp Suite which uses AWS API Gateway to rotate your IP on every request. - PortSwigger/ip-rotate**
github.com](https://github.com/PortSwigger/ip-rotate)

### BAYPASSING :

1- USE FAKEIP (BURPEXTENTION) FOR  BAYPASSING IP BLOCKING  TO DOWNLOAD IT AND CONFIG  

[https://www.youtube.com/watch?v=WEXH6goRkCk&ab_channel=CyberIntruder](https://www.youtube.com/watch?v=WEXH6goRkCk&ab_channel=CyberIntruder)

### **Tools**:

### 1- FAKEIP (BURPEXTENTION) TO DOWNLOAD IT AND CONFIG

### 2- THROTELL FOR  BLOCKING NUMBERS OF REQUESTS BYPASSING

### 3- NORLCHECK SCRIPT

![image.png](image%207.png)

# REPOS

WRITEUP FOR  RATE LIMIT BYPASSING 

[Mastering Rate Limit Bypass Techniques | by coffinxp | in InfoSec Write-ups - Freedium](https://freedium.cfd/https://infosecwriteups.com/mastering-rate-limit-bypass-techniques-fff9499b0f42)